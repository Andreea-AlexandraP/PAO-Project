package DatabaseConfig;
import java.sql.*;

public class DatabaseConfig {


    private static final String  url = "jdbc:mysql://localhost:3306/pao";
    private static final String username = "root";
    private static final String password = "root";

    static Connection connection = null;

    public DatabaseConfig() {
        try {
            connection = DriverManager.getConnection(url, username, password);
        }
        catch(SQLException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() {
        return connection;
    }

}
